# 🚨 Spam or Ham — Email Classifier

A clean, dark-themed ML project website that classifies emails as **spam** or **ham** using Claude AI (Naive Bayes + TF-IDF methodology), trained on the Kaggle SMS Spam Collection dataset.

![Spam or Ham](https://img.shields.io/badge/ML-Email%20Classifier-ff3b3b?style=flat-square) ![Claude AI](https://img.shields.io/badge/Powered%20by-Claude%20AI-4f8ef7?style=flat-square) ![Dataset](https://img.shields.io/badge/Dataset-Kaggle%20SMS%20Spam-00e5a0?style=flat-square)

---

## ✨ Features

- **Real-time email classification** — paste any email and get instant spam/ham verdict
- **Confidence scoring** — visual probability bars for spam vs. legitimate
- **Key signal detection** — shows which words/patterns triggered the classification
- **Sample emails** — load spam or legitimate email examples with one click
- **Classification history** — tracks your recent analyses in-session
- **Fully responsive** — works on desktop and mobile

---

## 🧠 How It Works

The classifier uses **Claude AI** (claude-sonnet-4-20250514) with a system prompt that mimics **Naive Bayes + TF-IDF** classification methodology:

- **Spam signals**: urgency language, prize/winner offers, suspicious URLs, ALL CAPS, excessive punctuation, financial promises, requests for personal data
- **Ham signals**: specific context, personal/professional tone, natural language, reasonable requests

Trained on the [Kaggle SMS Spam Collection Dataset](https://www.kaggle.com/code/yacermeftah/email-spam-detection/notebook) — 5,572 emails with 97.3% accuracy.

---

## 🚀 Getting Started

### 1. Clone the repo

```bash
git clone https://github.com/YOUR_USERNAME/spam-or-ham.git
cd spam-or-ham
```

### 2. Open in browser

This is a **pure front-end project** — no build step, no server needed.

```bash
# Option A: Open directly
open index.html

# Option B: Use a local server (recommended)
npx serve .
# or
python -m http.server 8000
```

### 3. Set up the Anthropic API

The app calls the Anthropic API directly from the browser. To use it:

1. Get an API key from [console.anthropic.com](https://console.anthropic.com)
2. You'll need a backend proxy or use it in a local dev environment where `anthropic-dangerous-direct-browser-access: true` is acceptable

> **Note**: For production use, route API calls through a backend server to keep your API key secure.

---

## 📁 Project Structure

```
spam-or-ham/
├── index.html    # Main HTML structure
├── style.css     # All styles (dark theme, responsive)
├── app.js        # Classification logic + API calls
└── README.md     # This file
```

---

## 🛠 Tech Stack

| Layer       | Technology          |
|-------------|---------------------|
| Frontend    | Vanilla HTML/CSS/JS |
| Fonts       | Syne, Space Mono (Google Fonts) |
| AI Model    | Claude Sonnet (Anthropic) |
| Dataset     | Kaggle SMS Spam Collection |
| Hosting     | GitHub Pages / any static host |

---

## 🌐 Deploy to GitHub Pages

1. Push the repo to GitHub
2. Go to **Settings → Pages**
3. Set source to `main` branch, `/ (root)` folder
4. Your site will be live at `https://YOUR_USERNAME.github.io/spam-or-ham/`

---

## 📊 Dataset Stats

| Metric           | Value  |
|------------------|--------|
| Total emails     | 5,572  |
| Spam emails      | 747    |
| Ham emails       | 4,825  |
| Spam ratio       | 13.4%  |
| Model accuracy   | 97.3%  |

---

## 📄 License

MIT — free to use for your ML projects.

---

*Built with ⚡ Claude AI · Anthropic*
