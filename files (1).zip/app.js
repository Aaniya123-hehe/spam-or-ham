/**
 * Spam or Ham — app.js
 * Email classifier powered by Claude AI (Anthropic API)
 * ML Project: Naive Bayes + TF-IDF methodology
 */

// ─── Sample Emails ────────────────────────────────────────────────────────────

const SPAM_SAMPLES = [
  "WINNER!! You've been selected as a LUCKY winner in our weekly draw! Claim your FREE cash prize of £1,000 NOW. Call 0800-WIN-NOW or reply CLAIM to this email. Offer expires in 24 HOURS. Don't miss out!!!",
  "Congratulations! Your email has won $500,000 in the Microsoft Annual Promotion. To claim, send your full name, bank details and a copy of your ID to: lottery@claims-winner.net. THIS IS NOT SPAM.",
  "URGENT NOTICE: Your account has been flagged for suspicious activity. Verify your identity IMMEDIATELY or your account will be permanently suspended. Click here → http://secure-verify-now.com/login",
  "Make $5000/week from home! No experience needed. Our proven system works 100% guaranteed. Hundreds of people are already earning. ACT NOW — limited spots available. Click to join FREE today!!"
];

const HAM_SAMPLES = [
  "Hi Sarah, just wanted to follow up on our meeting from yesterday. I've attached the revised proposal with the changes we discussed. Could you review it before Thursday? Let me know if you have any questions.",
  "Your Amazon order #302-9876543 has been shipped! Expected delivery: Wednesday, May 8. You can track your package by visiting your account or clicking the link in your Amazon app.",
  "Hey, are you free this weekend? A few of us are thinking of hiking up to the ridge on Saturday morning. Should be back by noon. Let me know if you want to join!",
  "Please find attached the Q2 financial summary for your review. Key highlights: revenue is up 12% YoY, and we've reduced operational costs by 8%. Happy to discuss the numbers on our weekly call."
];

// ─── State ────────────────────────────────────────────────────────────────────

let history = [];
let totalClassified = 0;

// ─── DOM Helpers ──────────────────────────────────────────────────────────────

const $ = id => document.getElementById(id);

// ─── Load Samples ─────────────────────────────────────────────────────────────

function loadSample(type) {
  const pool = type === 'spam' ? SPAM_SAMPLES : HAM_SAMPLES;
  const sample = pool[Math.floor(Math.random() * pool.length)];
  $('email-input').value = sample;
  updateCharCount();
  $('email-input').focus();
}

function clearInput() {
  $('email-input').value = '';
  updateCharCount();
  hideResult();
}

function updateCharCount() {
  const len = $('email-input').value.length;
  $('char-count').textContent = `${len} char${len !== 1 ? 's' : ''}`;
}

$('email-input').addEventListener('input', updateCharCount);

// Keyboard shortcut: Ctrl/Cmd + Enter to classify
$('email-input').addEventListener('keydown', e => {
  if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') classify();
});

// ─── Classify ─────────────────────────────────────────────────────────────────

async function classify() {
  const text = $('email-input').value.trim();
  if (!text) {
    alert('Please enter some email content to classify.');
    return;
  }

  setLoading(true);

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        system: `You are a precise email spam classifier using Naive Bayes + TF-IDF methodology, trained on the Kaggle SMS Spam Collection dataset (5,572 emails, 97.3% accuracy).

Classify emails as "spam" or "ham" and return ONLY a raw JSON object — no markdown, no backticks, no explanation outside the JSON.

JSON format:
{
  "verdict": "spam" or "ham",
  "confidence": number between 0.0 and 1.0,
  "reason": "One sentence explaining the main classification reason",
  "spam_signals": ["list", "of", "spam", "indicators", "found"],
  "ham_signals": ["list", "of", "legitimate", "indicators", "found"]
}

Spam indicators: urgency language, prize/winner/free offers, suspicious URLs, ALL CAPS, excessive punctuation, financial promises, requests for personal data, generic greetings.
Ham indicators: specific context, personal/professional tone, known sender references, natural language, reasonable requests.

Be precise. Base confidence on the strength of signals found.`,
        messages: [
          { role: 'user', content: `Classify this email:\n\n${text}` }
        ]
      })
    });

    const data = await response.json();

    if (data.error) {
      throw new Error(data.error.message || 'API error');
    }

    const rawText = data.content
      .filter(block => block.type === 'text')
      .map(block => block.text)
      .join('');

    // Strip any accidental markdown code fences
    const cleaned = rawText.replace(/```json|```/gi, '').trim();
    const result = JSON.parse(cleaned);

    showResult(result, text);

  } catch (err) {
    console.error('Classification error:', err);
    alert(`Classification failed: ${err.message}\n\nMake sure you have a valid Anthropic API key configured.`);
  } finally {
    setLoading(false);
  }
}

// ─── Loading State ────────────────────────────────────────────────────────────

function setLoading(loading) {
  const btn     = $('classify-btn');
  const label   = $('btn-label');
  const spinner = $('btn-spinner');

  btn.disabled           = loading;
  spinner.style.display  = loading ? 'block' : 'none';
  label.textContent      = loading ? 'Analyzing…' : 'Classify →';
}

// ─── Show Result ──────────────────────────────────────────────────────────────

function showResult(result, originalText) {
  const isSpam   = result.verdict === 'spam';
  const spamPct  = Math.round(result.confidence * 100);
  const hamPct   = 100 - spamPct;

  // Show result panel
  $('result-empty').style.display   = 'none';
  $('result-content').style.display = 'flex';
  $('result-content').style.flexDirection = 'column';

  // Verdict block
  const vBlock = $('verdict-block');
  vBlock.className = `verdict-block ${isSpam ? 'spam-result' : 'ham-result'}`;

  $('verdict-emoji').textContent = isSpam ? '🚨' : '✅';

  const vLabel = $('verdict-text');
  vLabel.className = `verdict-text ${isSpam ? 'spam-text' : 'ham-text'}`;
  vLabel.textContent = isSpam ? 'SPAM DETECTED' : 'LEGITIMATE EMAIL';

  const confLabel = spamPct >= 90 ? 'Very high confidence'
                  : spamPct >= 70 ? 'High confidence'
                  : spamPct >= 50 ? 'Moderate confidence'
                  : 'Low confidence';
  $('verdict-confidence').textContent = `${confLabel} · ${result.confidence.toFixed(2)} score`;

  // Probability bars (animate after brief delay)
  $('spam-pct').textContent = `${spamPct}%`;
  $('ham-pct').textContent  = `${hamPct}%`;
  setTimeout(() => {
    $('spam-bar').style.width = `${spamPct}%`;
    $('ham-bar').style.width  = `${hamPct}%`;
  }, 60);

  // Reason
  $('reason-text').textContent = result.reason || '—';

  // Signals
  const spamSignalsEl = $('spam-signals');
  const hamSignalsEl  = $('ham-signals');
  spamSignalsEl.innerHTML = '';
  hamSignalsEl.innerHTML  = '';

  (result.spam_signals || []).slice(0, 4).forEach(s => {
    const el = document.createElement('div');
    el.className = 'signal-item spam-signal';
    el.textContent = s;
    spamSignalsEl.appendChild(el);
  });
  (result.ham_signals || []).slice(0, 4).forEach(s => {
    const el = document.createElement('div');
    el.className = 'signal-item ham-signal';
    el.textContent = s;
    hamSignalsEl.appendChild(el);
  });

  // Update total count
  totalClassified++;
  const countEl = $('live-count');
  countEl.textContent = totalClassified;
  // Briefly animate the count
  countEl.style.color = isSpam ? 'var(--spam)' : 'var(--ham)';
  setTimeout(() => { countEl.style.color = ''; }, 800);

  // Add to history
  addToHistory(originalText, result.verdict, spamPct);

  // Scroll result into view on mobile
  if (window.innerWidth <= 720) {
    $('result-panel').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
}

function hideResult() {
  $('result-empty').style.display   = 'flex';
  $('result-content').style.display = 'none';
  $('spam-bar').style.width = '0';
  $('ham-bar').style.width  = '0';
}

// ─── History ──────────────────────────────────────────────────────────────────

function addToHistory(text, verdict, pct) {
  const snippet = text.length > 70 ? text.slice(0, 70) + '…' : text;
  history.unshift({ snippet, verdict, pct });
  if (history.length > 8) history.pop();
  renderHistory();
}

function renderHistory() {
  const section = $('history-section');
  const list    = $('history-list');

  section.style.display = 'block';
  list.innerHTML = history.map(h => `
    <div class="history-item">
      <span class="h-badge ${h.verdict}">${h.verdict}</span>
      <span class="h-text">${escapeHtml(h.snippet)}</span>
      <span class="h-pct">${h.pct}%</span>
    </div>
  `).join('');
}

function clearHistory() {
  history = [];
  $('history-section').style.display = 'none';
}

function escapeHtml(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
